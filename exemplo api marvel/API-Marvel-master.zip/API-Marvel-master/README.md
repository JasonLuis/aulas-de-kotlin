# API-Marvel

<table>
    <tr>
        <td>
        <sub>
       	 	<h2>
			This project is about how to use an API of Marvel using JavaScript</br></br>
			 the methods used for the project:</br>
			GET - /v1/public/characters </br>
			GET - /V1/public/characters/{characterId}/stories</br>
			if you want to see more about the methods, here the docs:
			<a href="https://developer.marvel.com/docs">Marvel API</a>
       	 	</h2>
        </sub>
        </td>
    </tr>
</table>


