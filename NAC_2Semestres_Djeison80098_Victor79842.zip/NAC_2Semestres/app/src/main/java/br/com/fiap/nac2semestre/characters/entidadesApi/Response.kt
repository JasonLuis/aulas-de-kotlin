package br.com.fiap.nac2semestre.characters.entidadesApi

data class Response (
    val code: Int? = null,
    val etag: String? = null,
    val data: Data? = null
)