package br.com.fiap.nac2semestre.characters.entidadesApi

data class Series (
    val available:Int? = null,
    val items: List<Items>? = null
)