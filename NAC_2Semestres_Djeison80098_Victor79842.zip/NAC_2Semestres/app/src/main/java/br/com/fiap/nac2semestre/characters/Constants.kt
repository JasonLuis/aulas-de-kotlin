package br.com.fiap.nac2semestre.characters

const val CHAVE_PRIVADA = "5613881bf16bbdb7abe028e55778f90b30139d39"
const val CHAVE_PUBLICA = "1611ea3bc24cff75db4b4ca0afb199c6"
