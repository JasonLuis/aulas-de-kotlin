package br.com.fiap.nac2semestre.characters.entidadesApi

data class Thumbnail (
  val path: String? = null,
  val extension: String? = null
)