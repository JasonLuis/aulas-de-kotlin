package br.com.fiap.nac2semestre.characters.entidadesApi

class Data (
    val offset: Int? = null,
    val  limit: Int? = null,
    val total: Int? = null,
    val count: Int? = null,
    val results: List<Characters>?=null
)