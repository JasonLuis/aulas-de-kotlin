package br.com.fiap.roomdatabase.task

data class Task(
    val id: Long? = null,
    val description: String
)